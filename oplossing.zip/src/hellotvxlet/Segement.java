package hellotvxlet;

public class Segement {
    public int x = 0;
    public int y = 0;
    
    public Segement(int initx, int inity)
    {
        x = initx;
        y = inity;
    }
}

