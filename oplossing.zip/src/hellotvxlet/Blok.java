package hellotvxlet;


public class Blok {
    public int x;
    public int y;
    
    public boolean issnake = false;
    public boolean isfood = false;
    
    public Blok(int initx, int inity)
    {
        x = initx;
        y = inity;
    }
}